# CallHero: Project Overview & Access Request

**Date:** 2026-02-06
**Requested by:** cfossenier
**Accounts involved:** MS-Marketing (653614598774), MSI-ContactCenter (088040914383)

---

## What is CallHero?

CallHero is an internal automation tool that links Amazon Connect call recordings and transcripts to HubSpot support tickets. Today, when an agent handles a call, there is no automatic connection between the call data in Amazon Connect and the corresponding ticket in HubSpot. Supervisors and QA staff must manually locate recordings — a time-consuming, error-prone process.

With CallHero, an agent clicks a button in a Chrome extension after a call, enters the HubSpot ticket number, and the system automatically:

1. Retrieves the call recording (.wav) from S3
2. Retrieves the call transcript from Contact Lens (if enabled)
3. Uploads both files to the HubSpot ticket
4. Adds a note with call metadata (duration, agent, timestamp)

The entire process is asynchronous and queue-based. The agent's workflow is not interrupted — they click submit and move on.

Optionally, **Phase 2** adds a parallel analytics database (PostgreSQL) that stores call metadata and transcripts for internal reporting. Phase 2 is completely additive — it never touches the Phase 1 pipeline, and if it fails, HubSpot sync continues unaffected.

---

## Architecture

```
                        MS-Marketing (653614598774)
                       ┌──────────────────────────────────────────────────┐
                       │                                                  │
  Chrome Extension ──► │  SubmitLink Lambda  ──►  SQS Queue (Phase 1)     │
                       │  (Function URL)    │         │                   │
                       │                    │         ▼                   │
                       │                    │  ProcessCallLink Lambda ──────── ► HubSpot API
                       │                    │       │    │                │      (upload files,
                       │                    │       │    │                │       create notes)
                       │                    │       │    │                │
                       │                    └──►  SQS Queue (Phase 2)     │
                       │                              │                   │
                       │                              ▼                   │
                       │                   AnalyticsIngestion Lambda      │
                       │                         │         │              │
                       │                         │         ▼              │
                       │                         │    RDS PostgreSQL      │
                       │                         │    (analytics DB)      │
                       │                                    ▲              │
                       │                         EC2 Bastion (SSM only)   │
                       │                         psql, Docker/Metabase    │
                       └──────────────────────────────────────────────────┘
                                                 │
                              sts:AssumeRole ────┘ (cross-account, both Lambdas)
                                                 │
                       ┌─────────────────────────▼────────────────────────┐
                       │                                                  │
                       │  MSI-ContactCenter (088040914383)                │
                       │                                                  │
                       │  Amazon Connect    S3 (recordings)    KMS        │
                       │  Contact Lens      (encrypted .wav)              │
                       │                                                  │
                       └──────────────────────────────────────────────────┘
```

**Key point:** CallHero deploys entirely in the Marketing account. It only needs **read access** to the ContactCenter account — it never writes, modifies, or deletes anything there. Both the ProcessCallLink and AnalyticsIngestion Lambdas use the same cross-account role.

---

## Why Cross-Account Access is Needed

Amazon Connect and its call recordings live in `088040914383` (MSI-ContactCenter). CallHero's Lambda functions deploy in `653614598774` (MS-Marketing) because:

- Marketing owns the HubSpot integration and the tooling budget
- We have PowerUserAccess in Marketing (can deploy Lambda, SQS, SNS, etc.)
- We only have ReadOnlyAccess in ContactCenter (cannot deploy anything there)
- Keeping the application separate from the contact center infrastructure is good practice — it avoids any risk of accidentally affecting call center operations

The cross-account role is the standard AWS-recommended pattern for this. Our Lambdas (ProcessCallLink and AnalyticsIngestion) assume a narrowly-scoped role to read specific data, then return to their own account context.

---

## Security Considerations

### What CallHero CAN do (with the requested access)

| Action | Purpose | Scope |
|--------|---------|-------|
| Read call metadata | Get duration, agent, timestamps for the ticket note | Single contact at a time, by contact ID |
| Download call recordings | Attach .wav file to HubSpot ticket | Single file at a time, from `CallRecordings/` prefix only |
| Read call transcripts | Attach transcript to HubSpot ticket | Single contact at a time, via Contact Lens API |
| Decrypt recordings | Recordings are KMS-encrypted in S3 | One specific KMS key only |

### What CallHero CANNOT do

| Action | Why not |
|--------|---------|
| Modify or delete any Connect configuration | No write permissions granted |
| Modify or delete call recordings | `s3:PutObject`, `s3:DeleteObject` not granted |
| Access any S3 data outside `CallRecordings/*` | S3 policy scoped to that prefix only |
| Access any other KMS key | Policy scoped to single key ARN |
| Affect call routing, queues, or flows | No `connect:Update*`, `connect:Create*`, or `connect:Delete*` permissions |
| Access any other Connect instance | Policy scoped to instance `2dc580eb-2419-400b-84c9-d8a6d87f3cf3` only |
| Be assumed by anything other than CallHero | Trust policy restricts to 2 specific role ARNs (`callhero-process-call-link-{stage}-*` and `callhero-analytics-ingestion-{stage}-*`) in account `653614598774` only |

### Principle of Least Privilege

The cross-account role follows least-privilege design:

1. **Scoped to one Connect instance** — not a wildcard across all instances
2. **Scoped to one S3 prefix** — only `connect/membersolutions-prod/CallRecordings/*`, not the entire bucket
3. **Scoped to one KMS key** — only the key used for recording encryption
4. **Read-only** — no write, update, or delete permissions on any resource
5. **Trust restricted** — only two specific CallHero Lambda execution roles (`callhero-process-call-link-{stage}-*` and `callhero-analytics-ingestion-{stage}-*`) in one specific account can assume it (the `-*` suffix prevents prefix exploitation)
6. **15-minute max session** — assumed role credentials expire after 15 minutes
7. **CloudFormation managed** — the role is deployed via a template, making it auditable and version-controlled

### Network and Data Flow

- Call recordings are streamed to the Lambda's ephemeral `/tmp` storage (10GB, encrypted at rest) in 1MB chunks, uploaded to HubSpot, then cleaned up immediately after upload
- Phase 1: No call data is stored persistently in the Marketing account
- Phase 2 (optional): Call metadata and transcript text are stored in a private RDS PostgreSQL database for analytics. Call recordings are NOT stored — only metadata and text.
- HubSpot API calls use HTTPS with a Private App token stored in AWS SSM Parameter Store (SecureString, encrypted with KMS)
- The Lambda Function URL (used by the Chrome extension) requires API key authentication (X-Api-Key header, validated against DynamoDB) and accepts only `{contactId, ticketId}` pairs — it does not accept or return any call content
- SQS queues use AWS-managed SSE encryption; SNS topic uses KMS encryption (alias/aws/sns)
- X-Ray distributed tracing enabled on all Lambda functions for cross-account call visibility

### What Happens if Something Goes Wrong

- If the recording isn't ready yet → message goes back to the queue with exponential backoff (up to 10 retries)
- If max retries are exceeded → a note is added to the HubSpot ticket explaining the failure, and an email is sent to the admin via SNS
- If the recording is too large (>100MB) → same notification pattern, no upload attempted
- If the cross-account role assumption fails → the Lambda fails, SQS retries, admin is notified
- Separate dead-letter queues for Phase 1 and Phase 2 catch anything that fails all retries, with CloudWatch alarms that email the admin

---

## What We're Asking For

There are three separate tickets:

1. **TICKET-CONNECT** (`docs/tickets/20260206-ticket-connect-account.md`) — Changes in MSI-ContactCenter (088040914383)
   - Deploy a cross-account IAM role (CloudFormation template provided)
   - Update KMS key policy to allow the role to decrypt recordings
   - Enable Contact Lens on the Connect instance

2. **TICKET-MARKETING** (`docs/tickets/20260206-ticket-marketing-account.md`) — Changes in MS-Marketing (653614598774)
   - Add IAM permissions so we can run SAM deploys (or have DevOps run the initial deploy)
   - This is the **deployment blocker** — needed before anything can go live

3. **TICKET-MARKETING-PHASE2** (`docs/tickets/20260206-ticket-marketing-phase2.md`) — Phase 2 Analytics (MS-Marketing)
   - Informational: describes the analytics database deployment (RDS, VPC endpoints, subnet)
   - **No additional permissions needed** — covered by PowerUserAccess + Phase 1 IAM
   - Can be deferred — Phase 1 works independently without it

All tickets include step-by-step instructions, copy-paste scripts, and verification commands.

---

## Current Access Matrix (tested 2026-02-06)

### MSI-ContactCenter (088040914383) — AWSReadOnlyAccess

| Category | Action | Current | Needed |
|----------|--------|:-------:|:------:|
| Connect | `ListInstances` | YES | — |
| Connect | `ListQueues`, `ListUsers`, `ListContactFlows` | YES | — |
| Connect | `ListInstanceStorageConfigs` | YES | — |
| Connect | `DescribeContact` | NO | **YES** |
| Connect | `GetContactAttributes` | NO | **YES** |
| Connect | `DescribeInstance` | NO | — |
| Connect | `DescribeUser`, `DescribeQueue` | NO | — |
| Connect | `SearchContacts` | NO | — |
| Connect | `ListRealtimeContactAnalysisSegments` | NO | **YES** |
| S3 | `ListBucket` (recordings) | YES | YES |
| S3 | `HeadObject` (recordings) | NO | **YES** |
| S3 | `GetObject` (recordings) | NO | **YES** |
| KMS | `ListKeys` | YES | — |
| KMS | `DescribeKey` | NO | **YES** |
| KMS | `Decrypt` | NO | **YES** |
| IAM | `ListRoles` | YES | — |
| IAM | `CreateRole` | NO | **YES** (one-time) |

### MS-Marketing (653614598774) — AWSPowerUserAccess

| Category | Action | Current | Needed |
|----------|--------|:-------:|:------:|
| Lambda | Full access | YES | YES |
| SQS | Full access | YES | YES |
| SNS | Full access | YES | YES |
| SSM | Full access | YES | YES |
| CloudFormation | Full access | YES | YES |
| CloudWatch | Full access | YES | YES |
| IAM | `CreateRole`, `PassRole` | NO | **YES** |
| Cross-account | S3, Connect | NO | Via AssumeRole (both ProcessCallLink and AnalyticsIngestion) |

---

## Questions?

Contact cfossenier or reference the callhero repository for the full source code, CloudFormation templates, and Lambda implementations.
