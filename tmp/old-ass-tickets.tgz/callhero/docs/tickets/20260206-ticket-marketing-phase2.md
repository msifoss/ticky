# TICKET: MS-Marketing Account (653614598774) — Phase 2 Analytics

**Priority:** Low (not a blocker — Phase 1 works independently)
**Requested by:** cfossenier
**Project:** CallHero
**Date:** 2026-02-06
**Prerequisite:** Phase 1 must be deployed first (`docs/tickets/20260206-ticket-marketing-account.md`)

> **Context:** Please read `docs/tickets/20260206-overview-callhero-access-request.md` for full project background and security details.

---

## Summary

This ticket describes the **Phase 2 analytics deployment** for CallHero. Phase 2 adds a PostgreSQL database that stores call metadata and transcripts for internal analytics and reporting. It is completely optional — Phase 1 (HubSpot sync) works independently without it.

**No additional permissions are needed.** The IAM permissions from the Phase 1 ticket (`docs/tickets/20260206-ticket-marketing-account.md`) already cover Phase 2 Lambda roles. All other Phase 2 resources (RDS, VPC endpoints, subnets, security groups) are covered by our existing `AWSPowerUserAccess`.

This ticket is for **DevOps awareness and approval** of the infrastructure being deployed.

---

## What Gets Deployed

Phase 2 is gated by the SAM parameter `EnableAnalytics=true`. When enabled, it adds the following resources to the existing CallHero stack:

| Resource | Type | Purpose |
|----------|------|---------|
| RDS PostgreSQL (db.t4g.micro) | `AWS::RDS::DBInstance` | Analytics database (PostgreSQL 17 + pgvector) |
| DB Subnet Group | `AWS::RDS::DBSubnetGroup` | Spans 2 AZs (us-east-1a + us-east-1b) |
| Private Subnet (us-east-1b) | `AWS::EC2::Subnet` | Second AZ for RDS, CIDR `10.0.44.64/26` |
| DB Security Group | `AWS::EC2::SecurityGroup` | Allows PostgreSQL (5432) from Lambda SG only |
| Lambda Security Group | `AWS::EC2::SecurityGroup` | Attached to AnalyticsIngestion Lambda |
| STS VPC Endpoint | `AWS::EC2::VPCEndpoint` | Lambda → STS (assume cross-account role) |
| Secrets Manager VPC Endpoint | `AWS::EC2::VPCEndpoint` | Lambda → Secrets Manager (RDS password) |
| Connect VPC Endpoint | `AWS::EC2::VPCEndpoint` | Lambda → Connect API (call metadata) |
| CloudWatch Logs VPC Endpoint | `AWS::EC2::VPCEndpoint` | Lambda → CloudWatch Logs (log delivery from VPC) |
| AnalyticsIngestion Lambda | `AWS::Serverless::Function` | Processes call data, writes to RDS |
| Analytics SQS Queue | `AWS::SQS::Queue` | Receives messages from SubmitLink Lambda |
| Analytics Dead Letter Queue | `AWS::SQS::Queue` | Catches failed analytics messages (separate from Phase 1 DLQ) |
| Analytics DLQ Alarm | `AWS::CloudWatch::Alarm` | Alerts admin when messages land in analytics DLQ |
| Analytics Queue Depth Alarm | `AWS::CloudWatch::Alarm` | Alerts when analytics queue backlog exceeds 50 for 15 min |
| Analytics Error Alarm | `AWS::CloudWatch::Alarm` | Alerts when analytics Lambda errors >= 3 in 5 min |
| Analytics Duration Alarm | `AWS::CloudWatch::Alarm` | Alerts when analytics Lambda duration approaches timeout |
| DB Storage Low Alarm | `AWS::CloudWatch::Alarm` | Alerts when RDS free storage < 5 GB |
| DB CPU High Alarm | `AWS::CloudWatch::Alarm` | Alerts when RDS CPU > 80% sustained 15 min |

**Optional Bastion Host** (gated by `EnableBastion=true`, requires `EnableAnalytics=true`):

| Resource | Type | Purpose |
|----------|------|---------|
| Internet Gateway | `AWS::EC2::InternetGateway` | Internet access for bastion (SSM agent, updates, Docker) |
| Public Subnet (us-east-1a) | `AWS::EC2::Subnet` | Bastion host subnet, CIDR `10.0.44.128/26` |
| Route Table + Route | `AWS::EC2::RouteTable` + `Route` | Default route to IGW for public subnet |
| Bastion Security Group | `AWS::EC2::SecurityGroup` | No inbound rules. Egress: 5432→RDS, 443/80→internet |
| Bastion EC2 Instance | `AWS::EC2::Instance` | t4g.nano (ARM), Amazon Linux 2023, SSM agent, psql, Docker |
| Bastion IAM Role | `AWS::IAM::Role` | SSM managed policy, Secrets Manager read, CloudWatch Logs |
| Bastion SSM Log Group | `AWS::Logs::LogGroup` | SSM session audit logs (30d dev, 90d prod) |

### VPC: Marketing VPC (`vpc-04b59b3136e4a04e3`)

Phase 2 deploys into the existing Marketing VPC (CIDR `10.0.44.0/23`). It creates one new subnet (`10.0.44.64/26` in us-east-1b) alongside the existing private subnet in us-east-1a.

**No NAT Gateway is used.** The Lambda reaches AWS services via VPC Interface Endpoints, saving ~$32/mo compared to a NAT Gateway.

### Database

- **Engine:** PostgreSQL 17 with pgvector extension
- **Instance:** db.t4g.micro (2 vCPU, 1 GB RAM)
- **Storage:** 20 GB gp3, auto-scaling to 50 GB
- **Password:** Managed by AWS Secrets Manager (auto-rotated via `ManageMasterUserPassword`)
- **Backup:** 7 days (dev) / 30 days (prod), automated snapshots
- **Access:** Private only (not publicly accessible), Lambda security group only
- **SSL:** Enforced (rds.force_ssl=1 parameter group + sslmode=require in app)
- **Deletion protection:** Off for dev, on for prod (conditional on Stage)

### Data Flow

```
Chrome Extension → SubmitLink Lambda → Analytics SQS Queue → AnalyticsIngestion Lambda
                                                                    |         |
                                                                    v         v
                                                              Connect API   RDS PostgreSQL
                                                         (call metadata)  (writes call record
                                                                           + transcript)
```

The AnalyticsIngestion Lambda:
1. Receives `{contactId, ticketId}` from the analytics SQS queue
2. Assumes the cross-account role to fetch call metadata from Connect
3. Fetches the transcript from Contact Lens (if available)
4. Writes the call record and transcript to PostgreSQL

It does **not** download or store call recordings — only metadata and transcript text.

---

## Estimated Monthly Cost

| Resource | Monthly Cost |
|----------|-------------|
| RDS PostgreSQL db.t4g.micro | ~$15.00 |
| Storage (20 GB gp3) | ~$2.30 |
| VPC Endpoints (4 Interface) | ~$29.00 |
| Lambda (AnalyticsIngestion) | ~$0.10 per 1,000 calls |
| SQS (Analytics Queue + DLQ) | < $0.01 |
| EC2 t4g.nano (bastion, optional) | ~$3.07 |
| EBS 8 GB gp3 (bastion, optional) | ~$0.64 |
| **Total (without bastion)** | **~$48/mo** |
| **Total (with bastion)** | **~$52/mo** |

NAT Gateway avoided ($32/mo saved). Aurora Serverless v2 avoided ($44/mo minimum).

---

## Deploy Instructions

### Prerequisites

- Phase 1 CallHero stack deployed (`docs/tickets/20260206-ticket-marketing-account.md`)
- Cross-account role deployed (`docs/tickets/20260206-ticket-connect-account.md`)
- `psql` installed (`brew install libpq && brew link --force libpq`)

### Step 1: Deploy Phase 2 resources

```bash
cd infrastructure

# Build
sam build

# Deploy with analytics enabled (samconfig.toml has all other parameter defaults)
sam deploy --parameter-overrides \
  EnableAnalytics=true \
  SubnetId1=<existing-subnet-id-in-us-east-1a>
```

A `samconfig.toml` is included in the repo with dev and prod configs. You only need to add `EnableAnalytics=true` and `SubnetId1` as parameter overrides.

### Step 2: Apply database schema

```bash
# From the repo root:
bash scripts/migrate-db.sh

# Or for a specific stack:
bash scripts/migrate-db.sh --stack-name callhero-prod --profile default
```

The migration script:
1. Reads the RDS endpoint and Secrets Manager ARN from CloudFormation stack outputs
2. Fetches the database password from Secrets Manager
3. Tests the connection
4. Applies the schema (`infrastructure/db/001_initial_schema.sql`)

### Verify

```bash
# Check the stack outputs for the RDS endpoint
aws cloudformation describe-stacks \
  --stack-name callhero-dev \
  --query "Stacks[0].Outputs[?starts_with(OutputKey, 'Analytics')]" \
  --output table

# Should show:
# - AnalyticsQueueUrl
# - AnalyticsDeadLetterQueueUrl
# - AnalyticsDbEndpoint
# - AnalyticsDbSecretArn
```

---

## Rollback

Phase 2 can be completely removed without affecting Phase 1:

```bash
# Redeploy with analytics disabled — removes all Phase 2 resources
cd infrastructure
sam deploy --config-env dev --parameter-overrides EnableAnalytics=false
```

This removes the RDS instance (creates a final snapshot), VPC endpoints, subnet, security groups, analytics Lambda, and analytics queue. The Phase 1 pipeline (SubmitLink → SQS → ProcessCallLink → HubSpot) continues unaffected.

**Note:** The RDS instance has `DeletionPolicy: Snapshot`, so a final snapshot is automatically created before the database is deleted.

---

## Security Notes

- The RDS instance is in a private subnet with no public access
- Database password is managed by AWS Secrets Manager (never stored in parameters or code)
- Only the AnalyticsIngestion Lambda security group can reach port 5432
- Lambda security group has **explicit egress rules** (5432→DB, 443→VPC endpoints) — default egress is inert (no NAT/IGW route in private subnets)
- RDS enforces SSL connections via `rds.force_ssl=1` parameter group; Lambda connects with `sslmode=require`
- DeletionProtection is **true** for prod, **false** for dev (conditional on Stage)
- BackupRetentionPeriod is **30 days** for prod, **7 days** for dev
- Transcript text is capped at 5 MB to prevent Lambda OOM or DB timeout
- Cross-account sessions are 15 minutes max (not 1 hour), cached for 13 minutes
- The Lambda uses the same cross-account role as ProcessCallLink — no additional permissions in the ContactCenter account
- Call recordings are **not** stored in the database — only metadata (duration, agent, timestamps) and transcript text
- **Bastion (optional):** Accessible only via SSM Session Manager — no SSH keys, no open ports, no security group ingress rules. IMDSv2 enforced, EBS encrypted at rest. SSM sessions logged to CloudWatch. Egress restricted to port 5432 (RDS) and 443/80 (internet for SSM agent and updates)

---

## Database Schema

Two tables are created by the migration (plus a `schema_migrations` tracking table):

```
calls                          transcripts
──────────────────             ──────────────────
id          BIGINT PK          id          BIGINT PK
contact_id  UUID UNIQUE        call_id     BIGINT FK → (UNIQUE)
ticket_id   TEXT               full_text   TEXT
agent_id    TEXT               turn_count  INTEGER
queue_name  TEXT               embedding   vector(1536)
initiation_ts TIMESTAMPTZ      created_at  TIMESTAMPTZ
disconnect_ts TIMESTAMPTZ
duration_secs INTEGER
recording_key TEXT
has_transcript BOOLEAN
created_at  TIMESTAMPTZ
updated_at  TIMESTAMPTZ
```

The `embedding` column (pgvector) is for future semantic search over call transcripts. Schema is idempotent — safe to run `migrate-db.sh` multiple times.

---

## Reference

| Item | Value |
|------|-------|
| Marketing Account | `653614598774` (MS-Marketing) |
| VPC | `vpc-04b59b3136e4a04e3` (CIDR `10.0.44.0/23`) |
| New Subnet CIDR | `10.0.44.64/26` (us-east-1b) |
| RDS Instance Class | db.t4g.micro |
| RDS Engine | PostgreSQL 17 + pgvector |
| Database Name | `callhero` |
| Database User | `callhero_admin` |
| SAM Parameter | `EnableAnalytics=true` |
| Migration Script | `scripts/migrate-db.sh` |
| Schema File | `infrastructure/db/001_initial_schema.sql` |
| Bastion Subnet CIDR | `10.0.44.128/26` (us-east-1a, public) |
| Bastion SAM Parameter | `EnableBastion=true` (requires `EnableAnalytics=true`) |
| Bastion Instance Type | `t4g.nano` (upgrade to `t4g.small` for Metabase) |
| Phase 1 Ticket | `docs/tickets/20260206-ticket-marketing-account.md` |
| ContactCenter Ticket | `docs/tickets/20260206-ticket-connect-account.md` |
