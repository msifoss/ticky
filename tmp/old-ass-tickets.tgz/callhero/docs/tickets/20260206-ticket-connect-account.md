# TICKET: MSI-ContactCenter Account (088040914383)

**Priority:** High
**Requested by:** cfossenier
**Project:** CallHero
**Date:** 2026-02-06
**Estimated time:** 15-20 minutes

> **Context:** Please read `docs/tickets/20260206-overview-callhero-access-request.md` for full project background and security details.

---

## Summary

Three changes are needed in the MSI-ContactCenter account (`088040914383`) to allow CallHero (running in MS-Marketing `653614598774`) to read call recordings and metadata from Amazon Connect. Two CallHero Lambdas use this cross-account access: **ProcessCallLink** (syncs recordings to HubSpot) and **AnalyticsIngestion** (writes call metadata to the analytics database).

| # | Task | Method | Risk |
|---|------|--------|------|
| 1 | Create cross-account IAM role | CloudFormation (template provided) | Low — read-only role, narrowly scoped |
| 2 | Update KMS key policy | CLI command (provided) | Low — adds one decrypt principal |
| 3 | Enable Contact Lens | Connect console | Low — enables analytics, no impact on call routing |

---

## Prerequisites

- AWS CLI configured with **admin access** to account `088040914383`
- The CloudFormation template file from the callhero repo: `infrastructure/cross-account-role.yaml`

If you don't have the repo checked out, the template contents are included at the bottom of this ticket as Appendix A.

---

## Task 1: Deploy the Cross-Account IAM Role

This creates a read-only role that CallHero Lambdas in the Marketing account can assume to access Connect data and call recordings. The trust policy is scoped to two specific Lambda role ARNs: `callhero-process-call-link-${Stage}-*` and `callhero-analytics-ingestion-${Stage}-*` (note the `-*` suffix — prevents prefix exploitation).

### What the role allows

- `connect:DescribeContact`, `connect:GetContactAttributes`, `connect:ListContactReferences` — read call metadata
- `connect:ListRealtimeContactAnalysisSegments` — read Contact Lens transcripts
- `s3:GetObject`, `s3:HeadObject` — download recordings from S3
- `s3:ListBucket` — list recordings (scoped to `CallRecordings/` prefix only)
- `kms:Decrypt`, `kms:DescribeKey` — decrypt KMS-encrypted recordings

### What the role does NOT allow

- No write/update/delete on any resource
- No access outside the single Connect instance `2dc580eb-2419-400b-84c9-d8a6d87f3cf3`
- No access outside the `CallRecordings/*` S3 prefix
- Cannot be assumed by anything other than `callhero-process-call-link-{stage}-*` and `callhero-analytics-ingestion-{stage}-*` roles in account `653614598774`

### Deploy command

```bash
# If you have the repo checked out:
aws cloudformation deploy \
  --template-file infrastructure/cross-account-role.yaml \
  --stack-name callhero-cross-account-role \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1

# All parameters have defaults pre-filled. To override the stage:
# --parameter-overrides Stage=prod
```

### Verify

```bash
# Confirm the role was created
aws iam get-role --role-name callhero-cross-account-read-dev

# Confirm the stack deployed successfully
aws cloudformation describe-stacks --stack-name callhero-cross-account-role --region us-east-1
```

Expected output: Role ARN should be `arn:aws:iam::088040914383:role/callhero-cross-account-read-dev`

---

## Task 2: Update the KMS Key Policy

Call recordings in S3 are encrypted with KMS key `31b18e92-5369-4567-9bb2-f2e642b6eb15`. The cross-account role needs `kms:Decrypt` permission, but KMS key policies require **both** an IAM policy (done in Task 1) **and** a key policy statement granting access.

### Step 2a: Get the current key policy

```bash
aws kms get-key-policy \
  --key-id arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15 \
  --policy-name default \
  --region us-east-1 \
  --output text > /tmp/kms-policy-current.json
```

### Step 2b: Review and edit the policy

Open `/tmp/kms-policy-current.json` and add the following statement to the `"Statement"` array:

```json
{
  "Sid": "AllowCallHeroDecrypt",
  "Effect": "Allow",
  "Principal": {
    "AWS": "arn:aws:iam::088040914383:role/callhero-cross-account-read-dev"
  },
  "Action": [
    "kms:Decrypt",
    "kms:DescribeKey"
  ],
  "Resource": "*"
}
```

Save the updated policy to `/tmp/kms-policy-updated.json`.

### Step 2c: Apply the updated key policy

```bash
aws kms put-key-policy \
  --key-id arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15 \
  --policy-name default \
  --policy file:///tmp/kms-policy-updated.json \
  --region us-east-1
```

### Verify

```bash
aws kms get-key-policy \
  --key-id arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15 \
  --policy-name default \
  --region us-east-1 \
  --output text | python3 -c "import sys,json; p=json.load(sys.stdin); [print('  FOUND: AllowCallHeroDecrypt') for s in p['Statement'] if s.get('Sid')=='AllowCallHeroDecrypt'] or print('  NOT FOUND')"
```

---

## Task 3: Enable Contact Lens

Contact Lens provides post-call transcripts and analytics. It is **not currently enabled** on the production Connect instance. Without it, CallHero can still sync call recordings but cannot attach transcripts to tickets.

### Steps

1. Open the AWS Console → Amazon Connect → Instances
2. Click on **membersolutions-prod** (`2dc580eb-2419-400b-84c9-d8a6d87f3cf3`)
3. In the left sidebar, click **Analytics tools**
4. Under **Contact Lens**, toggle it to **Enabled**
5. For storage, you can use the existing S3 bucket (`ms-prod-eus1-s3-connect`) or a new one — we just need the Contact Lens analysis output to be accessible

### Important notes

- Enabling Contact Lens **does not affect call routing or agent experience**
- It adds post-call analytics processing for new calls (it does not retroactively process old calls)
- There is an additional AWS cost — see [Contact Lens pricing](https://aws.amazon.com/connect/pricing/)
- If cost is a concern, this task can be deferred — CallHero will work for recordings without it

### Verify

```bash
# This requires DescribeInstanceAttribute permission:
aws connect describe-instance-attribute \
  --instance-id 2dc580eb-2419-400b-84c9-d8a6d87f3cf3 \
  --attribute-type CONTACT_LENS \
  --region us-east-1

# Should return: "Value": "true"

# Also verify storage config was created:
aws connect list-instance-storage-configs \
  --instance-id 2dc580eb-2419-400b-84c9-d8a6d87f3cf3 \
  --resource-type REAL_TIME_CONTACT_ANALYSIS_SEGMENTS \
  --region us-east-1

# Should return a StorageConfigs entry (not an empty list)
```

---

## End-to-End Verification Script

After all three tasks are complete, run the verification script from a machine with access to the Marketing account (`653614598774`):

```bash
# From the callhero repo root:

# Step 1: Verify role assumption works (no contact ID needed)
bash scripts/verify-connect-access.sh

# Step 2: Full verification with a real contact (requires a Contact ID from a recent call)
bash scripts/verify-connect-access.sh \
  --contact-id <UUID-of-a-recent-contact> \
  --recording-key "connect/membersolutions-prod/CallRecordings/2026/02/06/example.wav"
```

The script accepts `--stage`, `--contact-id`, `--recording-key`, `--instance-id`, `--bucket`, and `--profile` flags. Without `--contact-id`, steps 2-6 (Connect API, S3, Contact Lens) are gracefully skipped. Run `bash scripts/verify-connect-access.sh --help` for full usage.

**Prerequisites:** AWS CLI configured with `default` profile (MS-Marketing 653614598774), and the cross-account role must already be deployed (Task 1).

---

## Rollback

If any changes need to be reversed:

```bash
# Remove the cross-account role (Task 1)
aws cloudformation delete-stack --stack-name callhero-cross-account-role --region us-east-1

# Revert KMS key policy (Task 2)
# Restore from /tmp/kms-policy-current.json saved in Step 2a:
aws kms put-key-policy \
  --key-id arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15 \
  --policy-name default \
  --policy file:///tmp/kms-policy-current.json \
  --region us-east-1

# Disable Contact Lens (Task 3)
# Toggle off in the Connect console: Analytics tools → Contact Lens → Disable
```

---

## Appendix A: CloudFormation Template

If you don't have the repo, create a file called `cross-account-role.yaml` with the following contents and use it in the Task 1 deploy command:

```yaml
AWSTemplateFormatVersion: "2010-09-09"
Description: >
  CallHero cross-account role — deploy this in the ContactCenter account (088040914383).
  Grants the MS-Marketing account (653614598774) access to Amazon Connect APIs
  and call recording S3 bucket needed by CallHero Lambdas (ProcessCallLink and AnalyticsIngestion).

Parameters:
  Stage:
    Type: String
    Default: dev
    AllowedValues:
      - dev
      - prod
  MarketingAccountId:
    Type: String
    Default: "653614598774"
    Description: AWS account ID where CallHero Lambdas are deployed
  ConnectInstanceId:
    Type: String
    Default: 2dc580eb-2419-400b-84c9-d8a6d87f3cf3
    Description: Amazon Connect instance ID
  RecordingsBucketName:
    Type: String
    Default: ms-prod-eus1-s3-connect
    Description: S3 bucket containing call recordings
  RecordingsKmsKeyArn:
    Type: String
    Default: arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15
    Description: KMS key ARN used to encrypt call recordings

Resources:
  CallHeroCrossAccountRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub callhero-cross-account-read-${Stage}
      Description: Allows CallHero Lambdas (ProcessCallLink, AnalyticsIngestion) in the Marketing account to read Connect data and call recordings
      MaxSessionDuration: 900
      AssumeRolePolicyDocument:
        Version: "2012-10-17"
        Statement:
          - Effect: Allow
            Principal:
              AWS: !Sub arn:aws:iam::${MarketingAccountId}:root
            Action: sts:AssumeRole
            Condition:
              StringLike:
                aws:PrincipalArn:
                  - !Sub arn:aws:iam::${MarketingAccountId}:role/callhero-process-call-link-${Stage}-*
                  - !Sub arn:aws:iam::${MarketingAccountId}:role/callhero-analytics-ingestion-${Stage}-*
      Policies:
        - PolicyName: ConnectReadAccess
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Sid: DescribeContacts
                Effect: Allow
                Action:
                  - connect:DescribeContact
                  - connect:GetContactAttributes
                  - connect:ListContactReferences
                Resource:
                  - !Sub arn:aws:connect:us-east-1:088040914383:instance/${ConnectInstanceId}/contact/*
              - Sid: ContactLensRead
                Effect: Allow
                Action:
                  - connect:ListRealtimeContactAnalysisSegments
                Resource:
                  - !Sub arn:aws:connect:us-east-1:088040914383:instance/${ConnectInstanceId}/contact/*
        - PolicyName: RecordingsS3Read
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Sid: ReadRecordings
                Effect: Allow
                Action:
                  - s3:GetObject
                  - s3:HeadObject
                Resource:
                  - !Sub arn:aws:s3:::${RecordingsBucketName}/connect/membersolutions-prod/CallRecordings/*
              - Sid: ListRecordings
                Effect: Allow
                Action:
                  - s3:ListBucket
                Resource:
                  - !Sub arn:aws:s3:::${RecordingsBucketName}
                Condition:
                  StringLike:
                    s3:prefix: connect/membersolutions-prod/CallRecordings/*
        - PolicyName: KmsDecrypt
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Sid: DecryptRecordings
                Effect: Allow
                Action:
                  - kms:Decrypt
                  - kms:DescribeKey
                Resource:
                  - !Ref RecordingsKmsKeyArn

Outputs:
  CrossAccountRoleArn:
    Description: ARN of the cross-account role (use this in the CallHero SAM template)
    Value: !GetAtt CallHeroCrossAccountRole.Arn
  CrossAccountRoleName:
    Description: Name of the cross-account role
    Value: !Ref CallHeroCrossAccountRole
```

---

## Reference

| Item | Value |
|------|-------|
| Connect Instance ID | `2dc580eb-2419-400b-84c9-d8a6d87f3cf3` |
| Connect Instance Alias | `membersolutions-prod` |
| Connect Instance URL | `https://membersolutions-prod.my.connect.aws` |
| Recordings S3 Bucket | `ms-prod-eus1-s3-connect` |
| Recordings S3 Prefix | `connect/membersolutions-prod/CallRecordings/` |
| Recordings KMS Key ARN | `arn:aws:kms:us-east-1:088040914383:key/31b18e92-5369-4567-9bb2-f2e642b6eb15` |
| Marketing Account | `653614598774` (MS-Marketing) |
| ContactCenter Account | `088040914383` (MSI-ContactCenter) |
| Region | `us-east-1` |
