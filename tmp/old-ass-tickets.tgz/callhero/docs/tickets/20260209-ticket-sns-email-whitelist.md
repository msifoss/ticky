# TICKET: Whitelist AWS SNS Email Notifications

**Priority:** Medium
**Requested by:** cfossenier
**Project:** CallHero
**Date:** 2026-02-09
**Estimated time:** 5 minutes

---

## Summary

The CallHero stack (`callhero-dev`) was successfully deployed today. CloudFormation created an SNS topic (`callhero-admin-notifications-dev`) with an email subscription to `cfossenier@membersolutions.com`. The confirmation email from AWS SNS (`no-reply@sns.amazonaws.com`) is not arriving — likely blocked by the corporate email filter.

Without confirming the subscription, CloudWatch alarm notifications (DLQ messages, Lambda errors, throttles) will not be delivered. This is a monitoring gap.

## What's Needed

**One of the following:**

### Option A: Whitelist SNS Email (Preferred)

Whitelist the sender `no-reply@sns.amazonaws.com` in the corporate email filter/spam policy for `cfossenier@membersolutions.com` (and ideally `*@membersolutions.com` for future subscribers).

After whitelisting, we can re-trigger the confirmation email:
```bash
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:653614598774:callhero-admin-notifications-dev \
  --protocol email \
  --notification-endpoint cfossenier@membersolutions.com \
  --profile default
```

The user clicks the "Confirm subscription" link in the email — done.

### Option B: Confirm via AWS Console

If whitelisting is not possible, an admin with AWS Console access can:
1. Go to **SNS > Topics > callhero-admin-notifications-dev > Subscriptions**
2. Click **Request confirmation** to resend
3. Or provide the confirmation URL directly

### Option C: Use a Different Email

If the corporate filter cannot be changed, we can switch to a personal/alternative email:
```bash
# Remove current subscription (once confirmed, or wait for it to expire)
# Add alternative
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:653614598774:callhero-admin-notifications-dev \
  --protocol email \
  --notification-endpoint ALTERNATIVE_EMAIL_HERE
```

## Context

| Item | Value |
|------|-------|
| SNS Topic ARN | `arn:aws:sns:us-east-1:653614598774:callhero-admin-notifications-dev` |
| Subscription Status | `PendingConfirmation` |
| Target Email | `cfossenier@membersolutions.com` |
| SNS Sender | `no-reply@sns.amazonaws.com` |
| Subject Line | "AWS Notification - Subscription Confirmation" |
| Account | 653614598774 (MS-Marketing) |
| Stack | `callhero-dev` |

## Impact if Not Resolved

CloudWatch alarms for the following will fire silently (no email delivery):
- Dead-letter queue messages (failed recordings)
- Lambda errors and throttles
- Queue depth warnings
- Processing duration warnings

The system will still function — recordings will still be uploaded to HubSpot — but the admin won't know about failures until manually checking CloudWatch or the DLQ.

## Rollback

No rollback needed — this is an additive email filter change.
