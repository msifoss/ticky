# TICKET: MS-Marketing Account (653614598774)

**Priority:** High
**Requested by:** cfossenier
**Project:** CallHero
**Date:** 2026-02-06
**Estimated time:** 10 minutes

> **Context:** Please read `docs/tickets/20260206-overview-callhero-access-request.md` for full project background and security details.

---

## Summary

One change is needed in the MS-Marketing account (`653614598774`) so that we can deploy the CallHero application using AWS SAM (Serverless Application Model). SAM uses CloudFormation under the hood and needs to create IAM roles for the Lambda functions it deploys.

Our current permission set (`AWSPowerUserAccess`) does not include IAM actions. We need a scoped set of IAM permissions added.

| # | Task | Method | Risk |
|---|------|--------|------|
| 1 | Add scoped IAM permissions to our SSO role | SSO permission set update or inline policy | Low — scoped to `callhero-*` resources only |

**Alternative:** If adding IAM permissions is not approved, DevOps can run the SAM deploy on our behalf (instructions included below).

> **Note:** This same IAM permission covers both Phase 1 (HubSpot sync) and Phase 2 (analytics database). All CallHero Lambda execution roles are named `callhero-*`, so the scoped policy handles both phases without modification. No additional VPC, RDS, or database infrastructure requires IAM — those are all covered by PowerUserAccess. Phase 2 deployment details are in a separate ticket: `docs/tickets/20260206-ticket-marketing-phase2.md`.

---

## Prerequisites

- Admin access to AWS IAM Identity Center (SSO) for the organization, **or** admin access to account `653614598774`

---

## Option A: Add Scoped IAM Permissions (Preferred)

Add a **customer-managed policy** to the `AWSPowerUserAccess` permission set (or create a new permission set) that allows IAM operations **only for CallHero resources**.

### Policy to add

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "CallHeroIAMRoleManagement",
      "Effect": "Allow",
      "Action": [
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:GetRole",
        "iam:GetRolePolicy",
        "iam:TagRole",
        "iam:UntagRole",
        "iam:UpdateRole",
        "iam:UpdateRoleDescription",
        "iam:ListRoleTags",
        "iam:PutRolePolicy",
        "iam:DeleteRolePolicy",
        "iam:AttachRolePolicy",
        "iam:DetachRolePolicy",
        "iam:ListAttachedRolePolicies",
        "iam:ListRolePolicies"
      ],
      "Resource": "arn:aws:iam::653614598774:role/callhero-*"
    },
    {
      "Sid": "CallHeroIAMPassRole",
      "Effect": "Allow",
      "Action": "iam:PassRole",
      "Resource": "arn:aws:iam::653614598774:role/callhero-*",
      "Condition": {
        "StringEquals": {
          "iam:PassedToService": "lambda.amazonaws.com"
        }
      }
    },
    {
      "Sid": "CallHeroCloudFormationIAM",
      "Effect": "Allow",
      "Action": [
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:GetRole",
        "iam:GetRolePolicy",
        "iam:TagRole",
        "iam:UntagRole",
        "iam:PutRolePolicy",
        "iam:DeleteRolePolicy",
        "iam:AttachRolePolicy",
        "iam:DetachRolePolicy",
        "iam:ListAttachedRolePolicies",
        "iam:ListRolePolicies",
        "iam:PassRole"
      ],
      "Resource": "arn:aws:iam::653614598774:role/callhero-*Role*"
    }
  ]
}
```

### Security scoping

- All IAM actions are restricted to roles matching `callhero-*` — no access to any other IAM roles
- `iam:PassRole` is further restricted to only pass roles to `lambda.amazonaws.com`
- No permissions to create IAM users, groups, or policies outside the role scope
- No permissions to modify SSO configuration, permission sets, or other accounts

### How to apply

**Option A1: Via IAM Identity Center (if managed centrally)**

1. Open AWS IAM Identity Center (SSO)
2. Go to **Permission sets** → `AWSPowerUserAccess`
3. Under **Customer managed policies**, add the policy above as a new inline policy named `CallHeroIAMAccess`
4. This will apply to all accounts using this permission set — if that's too broad, create a new permission set `CallHeroDeveloper` with `AWSPowerUserAccess` + this inline policy and assign it only to the Marketing account

**Option A2: Via account-level IAM (if per-account)**

```bash
# Create the policy
aws iam create-policy \
  --policy-name CallHeroIAMAccess \
  --policy-document file://callhero-iam-policy.json \
  --profile <admin-profile-for-653614598774>

# Attach to the SSO role (find the exact role name first)
aws iam attach-role-policy \
  --role-name AWSReservedSSO_AWSPowerUserAccess_6905f37d263b9390 \
  --policy-arn arn:aws:iam::653614598774:policy/CallHeroIAMAccess \
  --profile <admin-profile-for-653614598774>
```

### Verify

```bash
# Test that we can now create a role (dry run — we'll delete it right after)
aws iam create-role \
  --role-name callhero-test-probe \
  --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}' \
  --profile default

# If it succeeds, clean up:
aws iam delete-role --role-name callhero-test-probe --profile default

# Then do a full SAM deploy test:
cd /path/to/callhero/infrastructure
sam build
sam deploy --config-env dev
```

---

## Option B: DevOps Runs the SAM Deploy (Alternative)

If adding IAM permissions is not approved, DevOps can run the initial deployment. After the first deploy, we can update Lambda code without IAM permissions (CloudFormation only needs IAM for role creation, not for code updates).

### One-time deploy steps

```bash
# 1. Clone the callhero repo
git clone https://dev.azure.com/membersolutionsinc/DevOps/_git/callsync-hubspot
cd callhero/infrastructure

# 2. Build
sam build --template template.yaml

# 3. Deploy using samconfig.toml (included in repo with dev/prod configs)
#
# NOTE: HubSpot token must be created manually as SSM SecureString BEFORE deploying:
#   aws ssm put-parameter --name /callhero/dev/hubspot-access-token --type SecureString --value "$TOKEN"
#
# Update AdminEmail in samconfig.toml before deploying:
sam deploy --config-env dev
```

### After initial deploy

Once the CloudFormation stack exists with its IAM roles, we can update Lambda code ourselves using:

```bash
sam build && sam deploy --config-env dev --no-confirm-changeset
```

This only updates Lambda code and configuration — no IAM changes — so PowerUserAccess is sufficient for subsequent deploys.

---

## Rollback

**Option A rollback:**
```bash
# Remove the inline policy from the permission set (via IAM Identity Center console)
# Or detach the policy:
aws iam detach-role-policy \
  --role-name AWSReservedSSO_AWSPowerUserAccess_6905f37d263b9390 \
  --policy-arn arn:aws:iam::653614598774:policy/CallHeroIAMAccess

aws iam delete-policy \
  --policy-arn arn:aws:iam::653614598774:policy/CallHeroIAMAccess
```

**Option B rollback:**
```bash
# Delete the entire CallHero stack (removes all resources including IAM roles)
aws cloudformation delete-stack --stack-name callhero-dev --region us-east-1 --profile default
```

---

## Reference

| Item | Value |
|------|-------|
| Marketing Account | `653614598774` (MS-Marketing) |
| SSO Role Name | `AWSReservedSSO_AWSPowerUserAccess_6905f37d263b9390` |
| SSO User | `cfossenier` |
| SAM Template | `infrastructure/template.yaml` |
| Phase 1 Resources (SAM) | 2 Lambda functions, 2 SQS queues (main + DLQ), 1 SNS topic, 2 DynamoDB tables (API keys + idempotency), 3 CloudWatch LogGroups, 7 CloudWatch alarms (+ 6 conditional Phase 2 alarms), 2 IAM execution roles, X-Ray tracing enabled |
| Phase 2 Resources (SAM) | See `docs/tickets/20260206-ticket-marketing-phase2.md` — adds RDS, VPC endpoints, subnet, security groups, 1 Lambda, 1 SQS queue + dedicated DLQ |
