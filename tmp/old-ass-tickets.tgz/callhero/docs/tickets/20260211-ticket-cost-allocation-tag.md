# TICKET: Activate 'Project' Cost Allocation Tag in AWS Billing

**Priority:** Medium
**Requested by:** cfossenier
**Project:** CallHero
**Date:** 2026-02-11
**Estimated time:** 2 minutes

---

## Summary

CallHero tags all AWS resources with `Project=callhero` via CloudFormation. To enable cost tracking via Cost Explorer, the `Project` tag must be **activated as a cost allocation tag** in the AWS Billing console. This is a one-time manual step that requires billing administrator or root account access — it cannot be done via CLI or CloudFormation.

Without activation, the CallHero cost dashboard (weekly email + CloudWatch widgets + AWS Budget) will report "Data unavailable."

## What's Needed

**Activate the `Project` user-defined cost allocation tag** in the AWS Billing console.

### Steps

1. Sign in to **AWS Billing Console** (account **653614598774**, MS-Marketing) with billing admin or root access
2. Navigate to **Billing > Cost Allocation Tags**
   - Direct URL: `https://us-east-1.console.aws.amazon.com/billing/home#/tags`
3. Under **User-defined cost allocation tags**, find `Project`
4. Select the checkbox and click **Activate**
5. Verify status shows **Active**

**Optional:** Also activate `Environment` and `ManagedBy` tags if present (enables finer cost filtering).

> **Note:** Cost Explorer data filtered by this tag will appear ~24 hours after activation.

## What Depends on This

| Feature | Impact Without Tag |
|---------|-------------------|
| Weekly Report email | COST section shows "Data unavailable" |
| CloudWatch Dashboard | 3 cost widgets show no data |
| AWS Budget (`callhero-monthly-dev`) | Cannot filter by project, may report inaccurate spend |
| Cost Explorer API queries | `ce:GetCostAndUsage` returns empty results |

All features degrade gracefully — call recording linking to HubSpot is unaffected.

## Context

| Item | Value |
|------|-------|
| Account | 653614598774 (MS-Marketing) |
| Tag Key | `Project` |
| Tag Value | `callhero` |
| Tagged Resources | ~35 resources (Lambdas, SQS, DynamoDB, SNS, CloudWatch, etc.) |
| Tagged Since | 2026-02-09 (first SAM deploy) |
| Console URL | `https://us-east-1.console.aws.amazon.com/billing/home#/tags` |
| Stack | `callhero-dev` |

## Why This Can't Be Automated

AWS does not support activating cost allocation tags via CloudFormation, SAM, or the AWS CLI. The `aws ce` API can *query* costs but cannot *activate* tags. This is a Billing console-only operation.

## Rollback

No rollback needed — activating a cost allocation tag is additive and non-destructive. It only enables cost visibility; it does not change any resource behavior.
